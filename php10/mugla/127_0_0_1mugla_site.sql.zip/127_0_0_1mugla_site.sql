-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 21 Kas 2017, 12:13:30
-- Sunucu sürümü: 5.6.17
-- PHP Sürümü: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `mugla_site_vt`
--
CREATE DATABASE IF NOT EXISTS `mugla_site_vt` DEFAULT CHARACTER SET utf8 COLLATE utf8_turkish_ci;
USE `mugla_site_vt`;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `sayfalar_tablosu`
--

CREATE TABLE IF NOT EXISTS `sayfalar_tablosu` (
  `sayfa_no` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `sayfa_basligi` varchar(200) COLLATE utf8_turkish_ci NOT NULL,
  `sayfa_link` varchar(210) COLLATE utf8_turkish_ci NOT NULL,
  `sayfa_icerik` mediumtext COLLATE utf8_turkish_ci NOT NULL,
  `olusturma_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `duzenleme_tarihi` timestamp NOT NULL ON UPDATE CURRENT_TIMESTAMP,
  `dil` varchar(3) COLLATE utf8_turkish_ci NOT NULL DEFAULT 'TR',
  PRIMARY KEY (`sayfa_no`),
  UNIQUE KEY `sayfa_no` (`sayfa_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci AUTO_INCREMENT=2 ;

--
-- Tablo döküm verisi `sayfalar_tablosu`
--

INSERT INTO `sayfalar_tablosu` (`sayfa_no`, `sayfa_basligi`, `sayfa_link`, `sayfa_icerik`, `olusturma_tarihi`, `duzenleme_tarihi`, `dil`) VALUES
(1, 'Muğla tarihi', 'mugla-tarihi', 'Muğla M.Ö. kurulan medeniyetlerin beşiğidir.', '2017-11-21 11:11:17', '0000-00-00 00:00:00', 'TR');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
