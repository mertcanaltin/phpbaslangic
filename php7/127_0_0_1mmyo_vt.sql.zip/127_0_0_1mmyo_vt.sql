-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Anamakine: 127.0.0.1
-- Üretim Zamanı: 07 Kas 2017, 13:39:44
-- Sunucu sürümü: 5.6.17
-- PHP Sürümü: 5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Veritabanı: `mmyo_vt`
--
CREATE DATABASE IF NOT EXISTS `mmyo_vt` DEFAULT CHARACTER SET utf8 COLLATE utf8_turkish_ci;
USE `mmyo_vt`;

-- --------------------------------------------------------

--
-- Tablo için tablo yapısı `slayt_tablosu`
--

CREATE TABLE IF NOT EXISTS `slayt_tablosu` (
  `resim_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `resim` varchar(50) COLLATE utf8_turkish_ci NOT NULL,
  `baslik` varchar(200) COLLATE utf8_turkish_ci NOT NULL DEFAULT 'Muğla MYO',
  `aciklama` varchar(350) COLLATE utf8_turkish_ci DEFAULT NULL,
  `ekleme_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `degistirme_tarihi` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`resim_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_turkish_ci AUTO_INCREMENT=3 ;

--
-- Tablo döküm verisi `slayt_tablosu`
--

INSERT INTO `slayt_tablosu` (`resim_id`, `resim`, `baslik`, `aciklama`, `ekleme_tarihi`, `degistirme_tarihi`) VALUES
(1, 'resimler/slaytlar/resim1.jpg', 'Muğla MYO', NULL, '2017-11-07 12:21:35', '2017-11-07 12:21:35'),
(2, 'resimler/slaytlar/resim2.jpg', 'Bilgisayar Programcılığı N.Ö.', NULL, '2017-11-07 12:21:35', '2017-11-07 12:22:47');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
